"""Offline generator for the frontend dashboard mock fixture.

Reads the real `base_file.csv` pipeline export and computes KPIs + pivot
summaries following the rules agreed in SESSION_PLAN_FRONTEND_ENGINEER_1.md
(section 7). Writes a typed TypeScript fixture to
`frontend/lib/mock/dashboard.ts` that the dashboard page imports directly.

This script is NOT part of the app build - it is a one-off, offline tool.
Run it with the venv at backend/.venv (pandas is the only dependency needed):

    backend\\.venv\\Scripts\\python.exe scripts\\generate_mock_dashboard.py
"""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent.parent
CSV_PATH = ROOT / "base_file.csv"
OUTPUT_PATH = ROOT / "frontend" / "lib" / "mock" / "dashboard.ts"

# Sales Stage codes 00-08 are "Open"; 09 = Closed/WON; 10 = Closed/Lost;
# 11 = Closed/Scrapped; 12 = Closed/Shelved; 13 = Closed/Disqualified.
OPEN_STAGE_CODES = {f"{i:02d}" for i in range(0, 9)}
LATE_STAGE_CODES = {"06", "07", "08"}
WON_STAGE_CODE = "09"
LOST_STAGE_CODE = "10"

ANCHOR_TOTAL_PIPELINE = 2275.85
ANCHOR_CLOSED_WON = 84.1

# The 5 "(New)" Deal Status variants are the same semantic bucket as their base category
# (cross-validated against the source workbook's own Pivot tab - see
# SESSION_PLAN_FRONTEND_ENGINEER_1.md addendum). Merge them before pivoting.
DEAL_STATUS_MERGE_MAP = {
    "Win (New)": "Closed WON",
    "Lost (New)": "Closed LOST",
    "Scrapped (New)": "Closed Scrapped",
    "Disqualified (New)": "Closed Disqualified",
    "Shleved (New)": "Closed Shelved",  # sic - typo present in source data
}


def stage_code(stage: object) -> str:
    """Extract the leading 2-digit stage code, e.g. '09 - Closed/WON' -> '09'."""
    if not isinstance(stage, str):
        return ""
    return stage.strip()[:2]


def to_number(series: pd.Series) -> pd.Series:
    """Coerce a messy numeric-ish column to floats, treating blanks/'Not Available' as 0."""
    cleaned = series.astype(str).str.replace(",", "", regex=False).str.strip()
    cleaned = cleaned.replace({"Not Available": "0", "nan": "0", "": "0", "None": "0"})
    return pd.to_numeric(cleaned, errors="coerce").fillna(0.0)


def load_data() -> pd.DataFrame:
    # Line 1 = free-text note, line 2 = stray anchor totals, line 3 = real header.
    df = pd.read_csv(CSV_PATH, skiprows=2, dtype=str, low_memory=False)
    return df


def build_pivot(
    df: pd.DataFrame,
    column: str,
    *,
    open_only: bool,
    sort_by_stage: bool = False,
) -> list[dict]:
    subset = df[df["_is_open"]] if open_only else df
    subset = subset[subset[column].notna()]
    subset = subset[subset[column].astype(str).str.strip() != ""]

    grouped = (
        subset.groupby(column, dropna=True)
        .agg(value=("_effective_tcv", "sum"), count=("Opportunity ID", "nunique"))
        .reset_index()
    )
    grouped["value"] = grouped["value"].round(2)

    if sort_by_stage:
        grouped["_sort_key"] = grouped[column].apply(stage_code)
        grouped = grouped.sort_values("_sort_key")
    else:
        grouped = grouped.sort_values("value", ascending=False)

    return [
        {
            "label": str(row[column]).strip(),
            "value": float(row["value"]),
            "count": int(row["count"]),
        }
        for _, row in grouped.iterrows()
    ]


def to_ts_literal(obj, indent: int = 0) -> str:
    pad = "  " * indent
    pad_inner = "  " * (indent + 1)
    if isinstance(obj, dict):
        if not obj:
            return "{}"
        items = [f"{pad_inner}{key}: {to_ts_literal(value, indent + 1)}" for key, value in obj.items()]
        return "{\n" + ",\n".join(items) + "\n" + pad + "}"
    if isinstance(obj, list):
        if not obj:
            return "[]"
        items = [f"{pad_inner}{to_ts_literal(value, indent + 1)}" for value in obj]
        return "[\n" + ",\n".join(items) + "\n" + pad + "]"
    if isinstance(obj, bool):
        return "true" if obj else "false"
    if isinstance(obj, str):
        return json.dumps(obj)
    # numbers (int/float)
    return json.dumps(obj)


def write_fixture(dashboard: dict) -> None:
    OUTPUT_PATH.parent.mkdir(parents=True, exist_ok=True)
    content = (
        '// GENERATED FILE - do not edit by hand.\n'
        '// Produced by scripts/generate_mock_dashboard.py from base_file.csv.\n'
        'import type { DashboardResponse } from "../../types/dashboard";\n'
        "\n"
        f"export const mockDashboard: DashboardResponse = {to_ts_literal(dashboard)};\n"
    )
    OUTPUT_PATH.write_text(content, encoding="utf-8")
    print(f"Wrote fixture to {OUTPUT_PATH.relative_to(ROOT)}")


def main() -> None:
    df = load_data()

    df["_stage_code"] = df["Sales Stage"].apply(stage_code)
    df["_is_open"] = df["_stage_code"].isin(OPEN_STAGE_CODES)
    df["_is_won"] = df["_stage_code"] == WON_STAGE_CODE
    df["_is_lost"] = df["_stage_code"] == LOST_STAGE_CODE
    df["_is_late_stage_open"] = df["_is_open"] & df["_stage_code"].isin(LATE_STAGE_CODES)

    tcv = to_number(df["TCV ($Mn)"])
    contract_value_mn = to_number(df["Offering Contract Value ($)"]) / 1_000_000
    # Stage-9 rule: for Closed/WON rows, TCV is taken from Offering Contract Value ($).
    df["_effective_tcv"] = np.where(df["_is_won"], contract_value_mn, tcv)

    total_pipeline_tcv = round(float(df["_effective_tcv"].sum()), 2)
    open_pipeline_tcv = round(float(df.loc[df["_is_open"], "_effective_tcv"].sum()), 2)
    closed_won_tcv = round(float(df.loc[df["_is_won"], "_effective_tcv"].sum()), 2)
    late_stage_pipeline_tcv = round(float(df.loc[df["_is_late_stage_open"], "_effective_tcv"].sum()), 2)
    total_deals = int(df["Opportunity ID"].nunique())

    won_count = int(df.loc[df["_is_won"], "Opportunity ID"].nunique())
    lost_count = int(df.loc[df["_is_lost"], "Opportunity ID"].nunique())
    win_ratio = round(won_count / (won_count + lost_count), 4) if (won_count + lost_count) > 0 else 0.0

    df["_deal_status_merged"] = df["Deal Status"].replace(DEAL_STATUS_MERGE_MAP)

    dashboard = {
        "uploadId": "mock-base-file",
        "kpis": {
            "totalPipelineTcv": total_pipeline_tcv,
            "openPipelineTcv": open_pipeline_tcv,
            "closedWonTcv": closed_won_tcv,
            "lateStagePipelineTcv": late_stage_pipeline_tcv,
            "totalDeals": total_deals,
            "winRatio": win_ratio,
        },
        "salesStage": build_pivot(df, "Sales Stage", open_only=True, sort_by_stage=True),
        "salesStageAll": build_pivot(df, "Sales Stage", open_only=False, sort_by_stage=True),
        "geography": build_pivot(df, "Geography", open_only=True),
        "category": build_pivot(df, "Category ", open_only=True),
        "quarter": build_pivot(df, "Closure Projection", open_only=True),
        "dealStatus": build_pivot(df, "_deal_status_merged", open_only=False),
        "movementStatus": build_pivot(df, "Movement status", open_only=False),
        "ageingDeals": build_pivot(df, "Ageing Deals", open_only=True),
        "bg": build_pivot(df, "New BG", open_only=False),
    }

    print("--- Mock dashboard generation summary ---")
    print(f"Total Pipeline TCV : {total_pipeline_tcv}  (anchor ~= {ANCHOR_TOTAL_PIPELINE}, informational only)")
    print(f"Closed Won TCV     : {closed_won_tcv}  (anchor ~= {ANCHOR_CLOSED_WON}, informational only)")
    print(f"Open Pipeline TCV  : {open_pipeline_tcv}")
    print(f"Late Stage TCV     : {late_stage_pipeline_tcv}")
    print(f"Total Deals        : {total_deals}")
    print(f"Win Ratio          : {win_ratio}  (won={won_count}, lost={lost_count})")

    total_delta = abs(total_pipeline_tcv - ANCHOR_TOTAL_PIPELINE)
    won_delta = abs(closed_won_tcv - ANCHOR_CLOSED_WON)
    print(f"Anchor delta (informational only): total={total_delta:.2f}, closedWon={won_delta:.2f}")

    write_fixture(dashboard)


if __name__ == "__main__":
    main()
