// GENERATED FILE - do not edit by hand.
// Produced by scripts/generate_mock_dashboard.py from base_file.csv.
import type { DashboardResponse } from "../../types/dashboard";

export const mockDashboard: DashboardResponse = {
  uploadId: "mock-base-file",
  kpis: {
    totalPipelineTcv: 2275.85,
    openPipelineTcv: 1845.64,
    closedWonTcv: 109.75,
    lateStagePipelineTcv: 395.53,
    totalDeals: 2074,
    winRatio: 0.8646
  },
  salesStage: [
    {
      label: "00 - Suspecting",
      value: 217.19,
      count: 192
    },
    {
      label: "01 - Prospecting",
      value: 302.66,
      count: 210
    },
    {
      label: "02 - EOI/RFI in progress",
      value: 192.62,
      count: 135
    },
    {
      label: "03 - EOI/RFI Submitted",
      value: 246.85,
      count: 125
    },
    {
      label: "04 - RFP/Proposal in progress",
      value: 221.94,
      count: 135
    },
    {
      label: "05 - RFP Submitted",
      value: 268.86,
      count: 133
    },
    {
      label: "06 - Short Listed",
      value: 100.48,
      count: 62
    },
    {
      label: "07 - Selected",
      value: 98.51,
      count: 234
    },
    {
      label: "08 - Contract Negotiation",
      value: 196.54,
      count: 218
    }
  ],
  salesStageAll: [
    {
      label: "00 - Suspecting",
      value: 217.19,
      count: 192
    },
    {
      label: "01 - Prospecting",
      value: 302.66,
      count: 210
    },
    {
      label: "02 - EOI/RFI in progress",
      value: 192.62,
      count: 135
    },
    {
      label: "03 - EOI/RFI Submitted",
      value: 246.85,
      count: 125
    },
    {
      label: "04 - RFP/Proposal in progress",
      value: 221.94,
      count: 135
    },
    {
      label: "05 - RFP Submitted",
      value: 268.86,
      count: 133
    },
    {
      label: "06 - Short Listed",
      value: 100.48,
      count: 62
    },
    {
      label: "07 - Selected",
      value: 98.51,
      count: 234
    },
    {
      label: "08 - Contract Negotiation",
      value: 196.54,
      count: 218
    },
    {
      label: "09 - Closed/WON",
      value: 109.75,
      count: 281
    },
    {
      label: "10 - Closed/Lost",
      value: 29.68,
      count: 44
    },
    {
      label: "11 - Closed/Scrapped",
      value: 77.3,
      count: 83
    },
    {
      label: "12 - Closed/Shelved",
      value: 156.73,
      count: 185
    },
    {
      label: "13 - Closed/Disqualified",
      value: 56.75,
      count: 37
    }
  ],
  geography: [
    {
      label: "North America",
      value: 1173.23,
      count: 783
    },
    {
      label: "UK",
      value: 289.35,
      count: 165
    },
    {
      label: "Europe",
      value: 137.03,
      count: 143
    },
    {
      label: "Asia Pacific",
      value: 134.81,
      count: 203
    },
    {
      label: "India",
      value: 60.77,
      count: 78
    },
    {
      label: "Latam",
      value: 27.84,
      count: 41
    },
    {
      label: "MEA",
      value: 22.62,
      count: 31
    }
  ],
  category: [
    {
      label: "Application Migration & Modernization",
      value: 804.0,
      count: 576
    },
    {
      label: "AI",
      value: 404.45,
      count: 406
    },
    {
      label: "Infra modernization",
      value: 305.36,
      count: 246
    },
    {
      label: "Legacy Modernisation",
      value: 202.5,
      count: 70
    },
    {
      label: "Data Platform & Migration",
      value: 85.57,
      count: 114
    },
    {
      label: "Business Solutions",
      value: 23.46,
      count: 53
    },
    {
      label: "Consulting & Advisory",
      value: 19.48,
      count: 44
    },
    {
      label: "User experience",
      value: 0.82,
      count: 5
    }
  ],
  quarter: [
    {
      label: "Q2 27",
      value: 1034.41,
      count: 990
    },
    {
      label: "Q3 27",
      value: 578.39,
      count: 215
    },
    {
      label: "Q1 27",
      value: 136.29,
      count: 180
    },
    {
      label: "Q4 27",
      value: 87.21,
      count: 46
    },
    {
      label: "Q1 28",
      value: 4.93,
      count: 7
    },
    {
      label: "Q2 28",
      value: 3.76,
      count: 2
    },
    {
      label: "Q1 29",
      value: 0.55,
      count: 2
    },
    {
      label: "Q3 28",
      value: 0.05,
      count: 1
    },
    {
      label: "Q3 29",
      value: 0.05,
      count: 1
    }
  ],
  dealStatus: [
    {
      label: "Open",
      value: 1845.64,
      count: 1444
    },
    {
      label: "Closed Shelved",
      value: 156.73,
      count: 185
    },
    {
      label: "Closed WON",
      value: 109.75,
      count: 281
    },
    {
      label: "Closed Scrapped",
      value: 77.3,
      count: 83
    },
    {
      label: "Closed Disqualified",
      value: 56.75,
      count: 37
    },
    {
      label: "Closed LOST",
      value: 29.68,
      count: 44
    }
  ],
  movementStatus: [
    {
      label: "Not Moved",
      value: 2133.05,
      count: 1876
    },
    {
      label: "Moved",
      value: 115.86,
      count: 139
    },
    {
      label: "Re-entry/New",
      value: 26.94,
      count: 59
    }
  ],
  ageingDeals: [
    {
      label: "<2months",
      value: 812.25,
      count: 700
    },
    {
      label: "> 6months",
      value: 413.97,
      count: 237
    },
    {
      label: "<4months",
      value: 279.07,
      count: 276
    },
    {
      label: "<6months",
      value: 216.33,
      count: 98
    },
    {
      label: ">Older than a year",
      value: 124.02,
      count: 133
    }
  ],
  bg: [
    {
      label: "BFSI Americas",
      value: 475.68,
      count: 435
    },
    {
      label: "CBG",
      value: 462.15,
      count: 410
    },
    {
      label: "LSHCERU",
      value: 418.28,
      count: 331
    },
    {
      label: "BFSI RoW",
      value: 319.7,
      count: 238
    },
    {
      label: "MFG",
      value: 209.81,
      count: 188
    },
    {
      label: "CMI",
      value: 183.93,
      count: 200
    },
    {
      label: "PS",
      value: 85.46,
      count: 31
    },
    {
      label: "NGM",
      value: 56.62,
      count: 66
    },
    {
      label: "Tech Services",
      value: 35.84,
      count: 81
    },
    {
      label: "Japan Ops",
      value: 23.89,
      count: 87
    },
    {
      label: "EDU",
      value: 4.49,
      count: 7
    }
  ]
};
