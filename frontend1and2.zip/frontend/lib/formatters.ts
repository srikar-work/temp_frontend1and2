export function formatCurrencyMillions(value: number) {
  return `$${value.toLocaleString(undefined, {
    maximumFractionDigits: 2,
  })}M`;
}

export function formatPercent(value: number) {
  return `${(value * 100).toFixed(1)}%`;
}
