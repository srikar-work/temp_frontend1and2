import type { Deal, DealsResponse } from "../types/deal";
import type { UploadResponse } from "../types/upload";

const API_BASE_URL = process.env.NEXT_PUBLIC_API_BASE_URL || "http://localhost:8000";

export async function getHealthCheck() {
  const response = await fetch(`${API_BASE_URL}/health`);

  if (!response.ok) {
    throw new Error("Backend health check failed");
  }

  return response.json();
}

// Not yet wired up to the dashboard page - this round renders from the mock fixture
// in lib/mock/dashboard.ts. Defined ahead of time for the future live integration.
export async function getDashboard(uploadId: string) {
  const response = await fetch(`${API_BASE_URL}/dashboard/${uploadId}`);

  if (!response.ok) {
    throw new Error("Failed to load dashboard");
  }

  return response.json();
}

async function request<T>(path: string, options?: RequestInit): Promise<T> {
  const url = `${API_BASE_URL}${path}`;

  let response: Response;

  try {
    response = await fetch(url, options);
  } catch (error) {
    throw new Error(
      error instanceof Error ? error.message : "Unable to reach the API server. Please confirm the backend is running."
    );
  }

  if (!response.ok) {
    const message = await response.text();
    throw new Error(message || `Request failed: ${response.status}`);
  }

  return response.json() as Promise<T>;
}

export async function uploadPipelineFile(file: File): Promise<UploadResponse> {
  const formData = new FormData();
  formData.append("file", file);

  return request<UploadResponse>("/upload", {
    method: "POST",
    body: formData,
  });
}

export async function getDeals(uploadId: string): Promise<DealsResponse> {
  return request<DealsResponse>(`/deals/${uploadId}`);
}

export async function getDealDetail(uploadId: string, opportunityId: string): Promise<Deal | null> {
  const response = await request<{ deal: Deal | null }>(`/deals/${uploadId}/${opportunityId}`);
  return response.deal;
}

