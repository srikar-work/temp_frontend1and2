type Props = {
  validationErrors?: string[];
};

export function ValidationSummary({ validationErrors = [] }: Props) {
  if (validationErrors.length === 0) {
    return (
      <div className="rounded-xl border-2 border-green-200 bg-green-50 p-5 text-sm text-green-700 shadow-sm">
        <div className="flex items-start gap-2">
          <svg className="h-5 w-5 flex-shrink-0 font-bold" fill="currentColor" viewBox="0 0 20 20">
            <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
          </svg>
          <div>
            <p className="font-semibold">✓ All Good</p>
            <p className="text-xs opacity-75">No validation errors detected</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="rounded-xl border-2 border-red-200 bg-red-50 p-5 text-sm text-red-700 shadow-sm">
      <div className="flex items-start gap-2">
        <svg className="h-5 w-5 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
          <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
          </svg>
        <div className="flex-1">
          <p className="font-semibold">Validation Issues Found</p>
          <ul className="mt-2 space-y-1">
            {validationErrors.map((error, idx) => (
              <li key={`${error}-${idx}`} className="ml-1 text-xs opacity-90">
                • {error}
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
}
