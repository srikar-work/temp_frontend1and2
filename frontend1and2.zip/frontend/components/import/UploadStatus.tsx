import type { UploadResponse } from "../../types/upload";

type Props = {
  upload?: UploadResponse | null;
};

function getStatusColor(status: string) {
  switch (status) {
    case "completed":
      return "bg-green-50 border-green-200 text-green-700";
    case "failed":
      return "bg-red-50 border-red-200 text-red-700";
    case "processing":
      return "bg-blue-50 border-blue-200 text-blue-700";
    default:
      return "bg-gray-50 border-gray-200 text-gray-700";
  }
}

function getStatusIcon(status: string) {
  switch (status) {
    case "completed":
      return (
        <svg className="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
        </svg>
      );
    case "failed":
      return (
        <svg className="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
        </svg>
      );
    case "processing":
      return (
        <svg className="h-5 w-5 animate-spin" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
        </svg>
      );
    default:
      return null;
  }
}

export function UploadStatus({ upload }: Props) {
  if (!upload) return null;

  const colorClass = getStatusColor(upload.status);
  const statusIcon = getStatusIcon(upload.status);

  return (
    <div className={`rounded-xl border-2 ${colorClass} p-6 shadow-sm`}>
      <div className="flex items-start gap-3">
        {statusIcon && <div className="mt-0.5 flex-shrink-0">{statusIcon}</div>}
        <div className="flex-1">
          <h2 className="mb-4 text-lg font-semibold">Upload Status</h2>
          <dl className="grid gap-3 text-sm md:grid-cols-2">
            <div>
              <dt className="mb-1 font-medium opacity-75">File</dt>
              <dd className="font-medium">{upload.filename}</dd>
            </div>
            <div>
              <dt className="mb-1 font-medium opacity-75">Status</dt>
              <dd className="font-medium capitalize">{upload.status}</dd>
            </div>
            <div>
              <dt className="mb-1 font-medium opacity-75">Rows Detected</dt>
              <dd className="font-medium">{upload.rowCount ?? "--"}</dd>
            </div>
            <div>
              <dt className="mb-1 font-medium opacity-75">Upload ID</dt>
              <dd className="truncate font-mono text-xs">{upload.uploadId}</dd>
            </div>
          </dl>
          {upload.message && <p className="mt-3 text-xs opacity-75 italic">{upload.message}</p>}
        </div>
      </div>
    </div>
  );
}
