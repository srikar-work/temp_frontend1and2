"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { BarChart3, Upload, Table2, Settings } from "lucide-react";

const navItems = [
  { href: "/dashboard", label: "Dashboard", icon: BarChart3 },
  { href: "/import", label: "Import Data", icon: Upload },
  { href: "/deals", label: "Deals", icon: Table2 },
  { href: "/settings", label: "Settings", icon: Settings },
];

export function Sidebar() {
  const pathname = usePathname();

  return (
    <aside className="w-64 border-r bg-white px-4 py-6">
      <div className="mb-8">
        <h1 className="text-xl font-semibold text-gray-900">AWS Pipeline</h1>
        <p className="text-sm text-gray-500">Reporting Portal</p>
      </div>

      <nav className="space-y-2">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = pathname === item.href;
          return (
            <Link
              key={item.href}
              href={item.href}
              className={`flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium ${
                isActive ? "bg-gray-100 text-gray-900" : "text-gray-700 hover:bg-gray-100"
              }`}
            >
              <Icon className="h-4 w-4" />
              {item.label}
            </Link>
          );
        })}
      </nav>
    </aside>
  );
}
