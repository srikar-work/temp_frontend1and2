"use client";

import { useRouter } from "next/navigation";

export function Header() {
  const router = useRouter();

  function handleLogout() {
    window.localStorage.removeItem("latestUploadId");
    router.push("/login");
  }

  return (
    <header className="flex h-16 items-center justify-between border-b bg-white px-6">
      <div>
        <p className="text-sm text-gray-500">AWS Pipeline Reporting Application</p>
      </div>

      <div className="flex items-center gap-4">
        <span className="text-sm text-gray-600">Signed in user</span>
        <button
          onClick={handleLogout}
          className="rounded-md border px-3 py-1.5 text-sm hover:bg-gray-50"
        >
          Logout
        </button>
      </div>
    </header>
  );
}

