import type { Deal } from "../../types/deal";
import { formatCurrencyMillions } from "../../lib/formatters";

type Props = {
  deal: Deal | null;
};

export function DealDetailPanel({ deal }: Props) {
  if (!deal) {
    return (
      <div className="rounded-xl border bg-white p-6 shadow-sm text-sm text-gray-500">
        Select a deal to review its details.
      </div>
    );
  }

  return (
    <div className="rounded-xl border bg-white p-6 shadow-sm">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold">{deal.opportunityName}</h2>
          <p className="text-sm text-gray-500">{deal.opportunityId}</p>
        </div>
        <span className="rounded-full bg-blue-50 px-3 py-1 text-sm font-medium text-blue-700">
          {deal.dealStatus ?? "Review pending"}
        </span>
      </div>

      <dl className="mt-5 grid gap-4 text-sm md:grid-cols-2">
        <div>
          <dt className="text-gray-500">Account</dt>
          <dd className="font-medium">{deal.accountName ?? deal.groupClient ?? "--"}</dd>
        </div>
        <div>
          <dt className="text-gray-500">Stage</dt>
          <dd className="font-medium">{deal.salesStage ?? "--"}</dd>
        </div>
        <div>
          <dt className="text-gray-500">TCV</dt>
          <dd className="font-medium">{deal.tcvMn != null ? formatCurrencyMillions(deal.tcvMn) : "--"}</dd>
        </div>
        <div>
          <dt className="text-gray-500">Geography</dt>
          <dd className="font-medium">{deal.geography ?? "--"}</dd>
        </div>
      </dl>

      <div className="mt-6 rounded-lg bg-gray-50 p-4 text-sm text-gray-600">
        Additional opportunity details will be surfaced here once the backend endpoint is available.
      </div>
    </div>
  );
}
