"use client";

import type { Deal } from "../../types/deal";

type Props = {
  deals: Deal[];
  searchTerm: string;
  onSearchChange: (value: string) => void;
  selectedStage: string;
  onStageChange: (value: string) => void;
  selectedGeography: string;
  onGeographyChange: (value: string) => void;
};

export function DealFilters({
  deals,
  searchTerm,
  onSearchChange,
  selectedStage,
  onStageChange,
  selectedGeography,
  onGeographyChange,
}: Props) {
  const stageOptions = Array.from(new Set(deals.map((deal) => deal.salesStage).filter(Boolean))) as string[];
  const geographyOptions = Array.from(new Set(deals.map((deal) => deal.geography).filter(Boolean))) as string[];

  return (
    <div className="rounded-xl border bg-white p-4 shadow-sm">
      <div className="grid gap-4 md:grid-cols-[2fr_1fr_1fr]">
        <label className="text-sm text-gray-600">
          <span className="mb-1 block font-medium">Search deals</span>
          <input
            value={searchTerm}
            onChange={(event) => onSearchChange(event.target.value)}
            placeholder="Search by opportunity or client"
            className="w-full rounded-md border border-gray-200 px-3 py-2 text-sm"
          />
        </label>

        <label className="text-sm text-gray-600">
          <span className="mb-1 block font-medium">Sales stage</span>
          <select
            value={selectedStage}
            onChange={(event) => onStageChange(event.target.value)}
            className="w-full rounded-md border border-gray-200 px-3 py-2 text-sm"
          >
            <option value="">All stages</option>
            {stageOptions.map((stage) => (
              <option key={stage} value={stage}>
                {stage}
              </option>
            ))}
          </select>
        </label>

        <label className="text-sm text-gray-600">
          <span className="mb-1 block font-medium">Geography</span>
          <select
            value={selectedGeography}
            onChange={(event) => onGeographyChange(event.target.value)}
            className="w-full rounded-md border border-gray-200 px-3 py-2 text-sm"
          >
            <option value="">All geographies</option>
            {geographyOptions.map((geography) => (
              <option key={geography} value={geography}>
                {geography}
              </option>
            ))}
          </select>
        </label>
      </div>
    </div>
  );
}
