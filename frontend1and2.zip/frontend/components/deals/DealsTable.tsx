import type { Deal } from "../../types/deal";
import { formatCurrencyMillions } from "../../lib/formatters";

type Props = {
  deals: Deal[];
  onSelectDeal?: (deal: Deal) => void;
};

export function DealsTable({ deals, onSelectDeal }: Props) {
  return (
    <div className="overflow-hidden rounded-xl border bg-white shadow-sm">
      <table className="min-w-full divide-y divide-gray-200 text-sm">
        <thead className="bg-gray-50">
          <tr>
            <th className="px-4 py-3 text-left font-medium text-gray-500">Opportunity ID</th>
            <th className="px-4 py-3 text-left font-medium text-gray-500">Opportunity Name</th>
            <th className="px-4 py-3 text-left font-medium text-gray-500">Client</th>
            <th className="px-4 py-3 text-left font-medium text-gray-500">Stage</th>
            <th className="px-4 py-3 text-left font-medium text-gray-500">TCV</th>
            <th className="px-4 py-3 text-left font-medium text-gray-500">Geography</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-gray-100">
          {deals.map((deal) => (
            <tr
              key={deal.opportunityId}
              onClick={() => onSelectDeal?.(deal)}
              className="cursor-pointer hover:bg-gray-50"
            >
              <td className="px-4 py-3">{deal.opportunityId}</td>
              <td className="px-4 py-3 font-medium">{deal.opportunityName}</td>
              <td className="px-4 py-3">{deal.accountName ?? deal.groupClient ?? "--"}</td>
              <td className="px-4 py-3">{deal.salesStage ?? "--"}</td>
              <td className="px-4 py-3">{deal.tcvMn != null ? formatCurrencyMillions(deal.tcvMn) : "--"}</td>
              <td className="px-4 py-3">{deal.geography ?? "--"}</td>
            </tr>
          ))}
        </tbody>
      </table>

      {deals.length === 0 ? (
        <div className="p-8 text-center text-sm text-gray-500">No deals available.</div>
      ) : null}
    </div>
  );
}

