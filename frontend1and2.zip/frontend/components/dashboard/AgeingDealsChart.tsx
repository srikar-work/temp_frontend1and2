import { PivotBarChart } from "./PivotBarChart";
import type { PivotDatum } from "../../types/dashboard";

export function AgeingDealsChart({ data }: { data: PivotDatum[] }) {
  return <PivotBarChart title="Ageing Deals" data={data} />;
}
