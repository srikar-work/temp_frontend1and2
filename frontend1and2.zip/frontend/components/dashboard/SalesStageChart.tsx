import { PivotBarChart } from "./PivotBarChart";
import type { PivotDatum } from "../../types/dashboard";

export function SalesStageChart({ data }: { data: PivotDatum[] }) {
  return <PivotBarChart title="Sales Stage Breakdown" data={data} />;
}
