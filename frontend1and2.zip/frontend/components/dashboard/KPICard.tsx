type KPICardProps = {
  title: string;
  value: string | number;
  description?: string;
};

export function KPICard({ title, value, description }: KPICardProps) {
  return (
    <div className="rounded-xl border bg-white p-5 shadow-sm">
      <p className="text-sm font-medium text-gray-500">{title}</p>
      <p className="mt-3 text-2xl font-semibold text-gray-900">{value}</p>
      {description ? <p className="mt-1 text-xs text-gray-500">{description}</p> : null}
    </div>
  );
}
