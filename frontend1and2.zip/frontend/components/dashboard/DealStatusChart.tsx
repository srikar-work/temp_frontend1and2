import { PivotBarChart } from "./PivotBarChart";
import type { PivotDatum } from "../../types/dashboard";

export function DealStatusChart({ data }: { data: PivotDatum[] }) {
  return <PivotBarChart title="Deal Status Breakdown" data={data} />;
}
