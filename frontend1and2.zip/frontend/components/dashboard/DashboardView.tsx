"use client";

import { useMemo, useState } from "react";
import { DashboardFilters } from "./DashboardFilters";
import type { FilterOption } from "./DashboardFilters";
import { KPICard } from "./KPICard";
import { SalesStageChart } from "./SalesStageChart";
import { GeographyChart } from "./GeographyChart";
import { CategoryChart } from "./CategoryChart";
import { QuarterChart } from "./QuarterChart";
import { DealStatusChart } from "./DealStatusChart";
import { MovementStatusChart } from "./MovementStatusChart";
import { AgeingDealsChart } from "./AgeingDealsChart";
import { BGChart } from "./BGChart";
import { formatCurrencyMillions, formatPercent } from "../../lib/formatters";
import type { DashboardResponse, PivotDatum } from "../../types/dashboard";

type Props = {
  data: DashboardResponse;
};

function optionsWithAll(pivot: PivotDatum[]) {
  return ["All", ...pivot.map((datum) => datum.label)];
}

export function DashboardView({ data }: Props) {
  const [filterValues, setFilterValues] = useState<Record<string, string>>({
    quarter: "All",
    geography: "All",
    category: "All",
    bg: "All",
    salesStage: "All",
    dealStatus: "All",
    ageingDeals: "All",
    movementStatus: "All",
  });

  const updateFilter = (key: string, value: string) =>
    setFilterValues((prev) => ({ ...prev, [key]: value }));

  const quarters = useMemo(() => optionsWithAll(data.quarter), [data.quarter]);
  const geographies = useMemo(() => optionsWithAll(data.geography), [data.geography]);
  const categories = useMemo(() => optionsWithAll(data.category), [data.category]);
  const bgOptions = useMemo(() => optionsWithAll(data.bg), [data.bg]);
  const salesStageOptions = useMemo(() => optionsWithAll(data.salesStageAll), [data.salesStageAll]);
  const dealStatusOptions = useMemo(() => optionsWithAll(data.dealStatus), [data.dealStatus]);
  const ageingDealsOptions = useMemo(() => optionsWithAll(data.ageingDeals), [data.ageingDeals]);
  const movementStatusOptions = useMemo(
    () => optionsWithAll(data.movementStatus),
    [data.movementStatus]
  );

  const filters: FilterOption[] = [
    { key: "quarter", label: "Quarter", options: quarters, value: filterValues.quarter, onChange: (v) => updateFilter("quarter", v) },
    { key: "geography", label: "Geography", options: geographies, value: filterValues.geography, onChange: (v) => updateFilter("geography", v) },
    { key: "category", label: "Category", options: categories, value: filterValues.category, onChange: (v) => updateFilter("category", v) },
    { key: "bg", label: "BG", options: bgOptions, value: filterValues.bg, onChange: (v) => updateFilter("bg", v) },
    { key: "salesStage", label: "Sales Stage", options: salesStageOptions, value: filterValues.salesStage, onChange: (v) => updateFilter("salesStage", v) },
    { key: "dealStatus", label: "Deal Status", options: dealStatusOptions, value: filterValues.dealStatus, onChange: (v) => updateFilter("dealStatus", v) },
    { key: "ageingDeals", label: "Ageing Deals", options: ageingDealsOptions, value: filterValues.ageingDeals, onChange: (v) => updateFilter("ageingDeals", v) },
    { key: "movementStatus", label: "Movement Status", options: movementStatusOptions, value: filterValues.movementStatus, onChange: (v) => updateFilter("movementStatus", v) },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-semibold text-gray-900">Dashboard</h1>
        <p className="text-gray-500">AWS pipeline summary metrics and pivot-style charts.</p>
      </div>

      <DashboardFilters filters={filters} />

      <section className="grid gap-4 md:grid-cols-3 xl:grid-cols-6">
        <KPICard title="Total Pipeline" value={formatCurrencyMillions(data.kpis.totalPipelineTcv)} />
        <KPICard title="Open Pipeline" value={formatCurrencyMillions(data.kpis.openPipelineTcv)} />
        <KPICard title="Closed Won" value={formatCurrencyMillions(data.kpis.closedWonTcv)} />
        <KPICard title="Late Stage" value={formatCurrencyMillions(data.kpis.lateStagePipelineTcv)} />
        <KPICard title="Total Deals" value={data.kpis.totalDeals} />
        <KPICard title="Win Ratio" value={formatPercent(data.kpis.winRatio)} />
      </section>

      <section className="grid gap-4 xl:grid-cols-2">
        <SalesStageChart data={data.salesStage} />
        <GeographyChart data={data.geography} />
        <CategoryChart data={data.category} />
        <QuarterChart data={data.quarter} />
        <DealStatusChart data={data.dealStatus} />
        <MovementStatusChart data={data.movementStatus} />
        <AgeingDealsChart data={data.ageingDeals} />
        <BGChart data={data.bg} />
      </section>
    </div>
  );
}
