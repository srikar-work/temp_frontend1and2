import { PivotBarChart } from "./PivotBarChart";
import type { PivotDatum } from "../../types/dashboard";

export function GeographyChart({ data }: { data: PivotDatum[] }) {
  return <PivotBarChart title="Pipeline by Geography" data={data} />;
}
