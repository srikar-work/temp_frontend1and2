import { PivotBarChart } from "./PivotBarChart";
import type { PivotDatum } from "../../types/dashboard";

export function BGChart({ data }: { data: PivotDatum[] }) {
  return <PivotBarChart title="Pipeline by Business Group" data={data} />;
}
