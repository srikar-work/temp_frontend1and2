"use client";

import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import type { PivotDatum } from "../../types/dashboard";
import { formatCurrencyMillions } from "../../lib/formatters";
import { EmptyState } from "../ui/EmptyState";

type Props = {
  title: string;
  data: PivotDatum[];
};

type ChartTooltipProps = {
  active?: boolean;
  payload?: ReadonlyArray<{ payload?: PivotDatum }>;
};

function ChartTooltip({ active, payload }: ChartTooltipProps) {
  if (!active || !payload || payload.length === 0) {
    return null;
  }

  const datum = payload[0]?.payload as PivotDatum | undefined;
  if (!datum) {
    return null;
  }

  return (
    <div className="rounded-lg border bg-white px-3 py-2 text-sm shadow-sm">
      <p className="font-medium text-gray-900">{datum.label}</p>
      <p className="text-gray-600">TCV: {formatCurrencyMillions(datum.value)}</p>
      {typeof datum.count === "number" ? (
        <p className="text-gray-600">Deals: {datum.count}</p>
      ) : null}
    </div>
  );
}

export function PivotBarChart({ title, data }: Props) {
  return (
    <div className="rounded-xl border bg-white p-6 shadow-sm">
      <h2 className="mb-4 text-lg font-semibold text-gray-900">{title}</h2>
      {data.length === 0 ? (
        <EmptyState message="No data available for this chart." />
      ) : (
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={data}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="label" tick={{ fontSize: 12 }} interval={0} angle={-25} textAnchor="end" height={90} />
              <YAxis />
              <Tooltip content={ChartTooltip} />
              <Bar dataKey="value" fill="#2563eb" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      )}
    </div>
  );
}
