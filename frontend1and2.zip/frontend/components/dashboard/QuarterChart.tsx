import { PivotBarChart } from "./PivotBarChart";
import type { PivotDatum } from "../../types/dashboard";

export function QuarterChart({ data }: { data: PivotDatum[] }) {
  return <PivotBarChart title="Pipeline by Quarter" data={data} />;
}
