import { PivotBarChart } from "./PivotBarChart";
import type { PivotDatum } from "../../types/dashboard";

export function MovementStatusChart({ data }: { data: PivotDatum[] }) {
  return <PivotBarChart title="Movement Status" data={data} />;
}
