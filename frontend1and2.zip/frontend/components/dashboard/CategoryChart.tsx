import { PivotBarChart } from "./PivotBarChart";
import type { PivotDatum } from "../../types/dashboard";

export function CategoryChart({ data }: { data: PivotDatum[] }) {
  return <PivotBarChart title="Pipeline by Category" data={data} />;
}
