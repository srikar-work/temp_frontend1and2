export type FilterOption = {
  key: string;
  label: string;
  options: string[];
  value: string;
  onChange: (value: string) => void;
};

type DashboardFiltersProps = {
  filters: FilterOption[];
};

export function DashboardFilters({ filters }: DashboardFiltersProps) {
  return (
    <section className="rounded-xl border bg-white p-4 shadow-sm">
      <div className="grid gap-4 sm:grid-cols-2 md:grid-cols-3 xl:grid-cols-4">
        {filters.map((filter) => (
          <label key={filter.key} className="space-y-1 text-sm">
            <span className="font-medium text-gray-700">{filter.label}</span>
            <select
              value={filter.value}
              onChange={(event) => filter.onChange(event.target.value)}
              className="w-full rounded-md border px-3 py-2"
            >
              {filter.options.map((option) => (
                <option key={option}>{option}</option>
              ))}
            </select>
          </label>
        ))}
      </div>
    </section>
  );
}
