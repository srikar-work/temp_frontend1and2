"use client";

import { useEffect, useState } from "react";
import { AppShell } from "../../components/layout/AppShell";
import { FileUploader } from "../../components/import/FileUploader";
import { UploadStatus } from "../../components/import/UploadStatus";
import { ValidationSummary } from "../../components/import/ValidationSummary";
import type { UploadResponse } from "../../types/upload";

export default function ImportPage() {
  const [uploadResponse, setUploadResponse] = useState<UploadResponse | null>(null);

  useEffect(() => {
    if (uploadResponse?.uploadId) {
      window.localStorage.setItem("latestUploadId", uploadResponse.uploadId);
    }
  }, [uploadResponse]);

  return (
    <AppShell>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-semibold">Import Data</h1>
          <p className="text-gray-500">Upload the AWS pipeline Base Data file for processing.</p>
        </div>

        <FileUploader onUploadComplete={setUploadResponse} />
        <UploadStatus upload={uploadResponse} />
        {uploadResponse ? <ValidationSummary validationErrors={uploadResponse.validationErrors} /> : null}
      </div>
    </AppShell>
  );
}

