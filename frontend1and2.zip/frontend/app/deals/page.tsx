"use client";

import { useMemo, useState } from "react";
import { AppShell } from "../../components/layout/AppShell";
import { DealDetailPanel } from "../../components/deals/DealDetailPanel";
import { DealFilters } from "../../components/deals/DealFilters";
import { DealsTable } from "../../components/deals/DealsTable";
import type { Deal } from "../../types/deal";

const mockDeals: Deal[] = [
  {
    opportunityId: "1887077",
    opportunityName: "App Mgmt Services for CardWorks",
    accountName: "CardWorks Servicing, LLC",
    salesStage: "01 - Prospecting",
    tcvMn: 1.68,
    geography: "North America",
    dealStatus: "Open",
  },
  {
    opportunityId: "1887088",
    opportunityName: "Cloud Migration for Northwind",
    accountName: "Northwind Traders",
    salesStage: "02 - EOI/RFI in progress",
    tcvMn: 4.2,
    geography: "Europe",
    dealStatus: "Open",
  },
  {
    opportunityId: "1887099",
    opportunityName: "Managed Support for Contoso",
    accountName: "Contoso Ltd.",
    salesStage: "03 - EOI/RFI Submitted",
    tcvMn: 2.9,
    geography: "Asia Pacific",
    dealStatus: "Review",
  },
];

export default function DealsPage() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedStage, setSelectedStage] = useState("");
  const [selectedGeography, setSelectedGeography] = useState("");
  const [selectedDeal, setSelectedDeal] = useState<Deal | null>(mockDeals[0]);

  const filteredDeals = useMemo(() => {
    const lowerSearch = searchTerm.trim().toLowerCase();

    return mockDeals.filter((deal) => {
      const matchesSearch =
        lowerSearch.length === 0 ||
        deal.opportunityName.toLowerCase().includes(lowerSearch) ||
        deal.accountName?.toLowerCase().includes(lowerSearch) ||
        deal.opportunityId.toLowerCase().includes(lowerSearch);

      const matchesStage = selectedStage === "" || deal.salesStage === selectedStage;
      const matchesGeography = selectedGeography === "" || deal.geography === selectedGeography;

      return matchesSearch && matchesStage && matchesGeography;
    });
  }, [searchTerm, selectedStage, selectedGeography]);

  return (
    <AppShell>
      <div className="space-y-8">
        <div>
          <h1 className="text-4xl font-bold text-gray-900">Deals</h1>
          <p className="mt-2 text-gray-600">Search, filter, and review individual opportunity records in your pipeline.</p>
        </div>

        <DealFilters
          deals={mockDeals}
          searchTerm={searchTerm}
          onSearchChange={setSearchTerm}
          selectedStage={selectedStage}
          onStageChange={setSelectedStage}
          selectedGeography={selectedGeography}
          onGeographyChange={setSelectedGeography}
        />

        <div className="grid gap-6 xl:grid-cols-[1fr_350px]">
          <div>
            <div className="mb-3 flex items-center justify-between">
              <h2 className="text-lg font-semibold text-gray-900">Opportunities</h2>
              <span className="text-sm text-gray-500">{filteredDeals.length} deal{filteredDeals.length !== 1 ? "s" : ""}</span>
            </div>
            <DealsTable deals={filteredDeals} onSelectDeal={setSelectedDeal} />
          </div>
          <div className="sticky top-6 h-fit">
            <h2 className="mb-3 text-lg font-semibold text-gray-900">Details</h2>
            <DealDetailPanel deal={selectedDeal} />
          </div>
        </div>
      </div>
    </AppShell>
  );
}

