import { AppShell } from "../../components/layout/AppShell";
import { DashboardView } from "../../components/dashboard/DashboardView";
import { mockDashboard } from "../../lib/mock/dashboard";

export default function DashboardPage() {
  return (
    <AppShell>
      <DashboardView data={mockDashboard} />
    </AppShell>
  );
}

