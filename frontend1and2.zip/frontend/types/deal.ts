export type Deal = {
  opportunityId: string;
  opportunityName: string;
  accountName?: string;
  groupClient?: string;
  salesStage?: string;
  tcvMn?: number;
  quarter?: string;
  geography?: string;
  category?: string;
  dealStatus?: string;
  movementStatus?: string;
  opportunityPrimary?: string;
};

export type DealsResponse = {
  uploadId: string;
  deals: Deal[];
};

