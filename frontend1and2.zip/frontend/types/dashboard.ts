export type DashboardKpis = {
  totalPipelineTcv: number;
  openPipelineTcv: number;
  closedWonTcv: number;
  lateStagePipelineTcv: number;
  totalDeals: number;
  winRatio: number;
};

export type PivotDatum = {
  label: string;
  value: number;
  count?: number;
};

export type DashboardResponse = {
  uploadId: string;
  kpis: DashboardKpis;
  salesStage: PivotDatum[];
  salesStageAll: PivotDatum[];
  geography: PivotDatum[];
  category: PivotDatum[];
  quarter: PivotDatum[];
  dealStatus: PivotDatum[];
  movementStatus: PivotDatum[];
  ageingDeals: PivotDatum[];
  bg: PivotDatum[];
};
