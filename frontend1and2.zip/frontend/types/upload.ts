export type UploadStatus = "pending" | "processing" | "completed" | "failed";

export type UploadRecord = {
  id: string;
  filename: string;
  uploadedAt: string;
  status: UploadStatus;
  rowCount?: number;
  validationErrors?: string[];
};

export type UploadResponse = {
  uploadId: string;
  filename: string;
  status: UploadStatus;
  rowCount?: number;
  validationErrors?: string[];
  message?: string;
};

